import express from 'express'
import { pet } from '../controller/pet_controller.js'

let router = express.Router()

router.get('/pet', pet.todos)
router.post('/pet', pet.create)
router.put('/pet/:codigo_pet',pet.update)
router.delete('/pet/:codigo_pet', pet.delete)
router.get('/pet/:genero_pet', pet.genero)

export {router}
