import connect from "../database/db.js";
let pet = {}
const con = await connect()

pet.genero = async function (req, res){
    try{
        let gen = req.params.genero_pet
        //let pet = req.body
        let sql = "SELECT codigo_pet, nome_pet, genero_pet FROM pet WHERE genero_pet = ?"
        let result = await con.query(sql, [gen])

        res.send({
            status: 'Pet:',
            result: result[0]
        })
    }catch (e){
        console.log("Erro......")
    }
}

pet.update = async function(req, res){

   try{ 
    let cod = req.params.codigo_pet;
    let pet = req.body
    let sql = 'UPDATE pet SET nome_pet=?, genero_pet=? WHERE codigo_pet = ?'
    const values = [pet.nome_pet, pet.genero_pet, [cod]]
    var result = await con.query(sql, values)

    res.send({
        status: "Pet foi atualizado",
        result: result[0]
    })
  }catch(e){
console.log("Erro.......")
  }
}

pet.create = async function(req, res){
    try{
        let pet = req.body
        let sql = 'INSERT INTO pet (codigo_pet, nome_pet, genero_pet) VALUES (?,?,?);'
        let values = [pet.codigo_pet, pet.nome_pet, pet.genero_pet]
        let result = await con.query(sql, values)

        res.send({
            status: 'Pet foi cadastrado',
            result: result[0]
        })


    }catch(e){

    }
}

pet.delete = async function (req, res){
    try{
        let cod = req.params.codigo_pet
        var sql = 'DELETE FROM pet WHERE codigo_pet=?'
        var result = await con.query(sql, [cod])

        res.send({
            status: 'PET foi deletado',
            result: result[0]
        })
    }catch(e){
        console.log("Erro..........")
    }
}

pet.todos = async function (req, res){
    try{
        let sql =  'SELECT * FROM pet'
        var result = await con.query(sql)
        res.send({
            status: 'Aqui estao os pets cadtrados:',
            result: result[0]
        })
    }catch(e){
        console.log("Erro.........")
    }
}

export {pet}